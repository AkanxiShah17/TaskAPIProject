using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace TaskAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
       
        //Add Tasks
        [HttpPost("AddTask")]
        public async Task<IActionResult> AddTask([FromBody] Tasks task)
        {
            try
            {
                await _taskService.AddTask(task);
                return Ok("Added");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message); ;
            }
        }
        //Delete Task
        [HttpDelete("DeleteTask")]
        public IActionResult DeleteTask(string name)
        {
            try
            {
                _taskService.DeleteTask(name);
                return Ok("Deleted");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); ;
            }
        }
        //Delete Task
        [HttpPut("UpdateTask")]
        public IActionResult UpdateTask(Tasks Object)
        {
            try
            {
                _taskService.UpdateTask(Object);
                return Ok("Added");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); ;
            }
        }


        //GET All Task
        [HttpGet("GetAllTasks")]
        public Object GetAllTasks()
        {
            var data = _taskService.GetAllTasks();
            var json = JsonConvert.SerializeObject(data, Formatting.Indented,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                }
            );
            return json;
        }
    }
}
