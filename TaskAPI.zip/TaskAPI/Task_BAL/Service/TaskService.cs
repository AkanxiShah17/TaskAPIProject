﻿using Task_BAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_BAL.Service
{
    public class TaskService
    {
        private readonly IRepository<Tasks> _tasks;

        public TaskService(IRepository<Tasks> tasks)
        {
            _tasks = tasks;
        }
        //Get Task Details By Task Id
        public IEnumerable<Tasks> GetTasksById(int id)
        {
            return _tasks.GetAll().Where(x => x.Id == id).ToList();
        }
        //GET All Perso Details 
        public IEnumerable<Tasks> GetAllTasks()
        {
            try
            {
                return _tasks.GetAll().ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        //Get Task by Task Name
        public Tasks GetTaskByName(string name)
        {
            return _tasks.GetAll().Where(x => x.Name == name).FirstOrDefault();
        }
        //Add Task
        public async Task<Tasks> AddTask(Tasks tasks)
        {
            ChecktoAddorUpdate(tasks);
            return await _tasks.Create(tasks);
        }

        private void ChecktoAddorUpdate(Tasks tasks)
        {
            int maxHighTask = 100;
            if (tasks.Status != "Finished" && tasks.Priority == "High")
            {

                var count = _tasks.GetAll().Where(x => x.Status != "Finished" && x.DueDate == tasks.DueDate && x.Priority == "High").ToList().Count();
                if (count >= maxHighTask)
                {
                    throw new Exception("App doesn't allow to create as it as max limit ");
                }
            }
        }

        //Delete Task 
        public bool DeleteTask(string name)
        {

            try
            {
                var DataList = _tasks.GetAll().Where(x => x.Name == name).ToList();
                foreach (var item in DataList)
                {
                    _tasks.Delete(item);
                }
                return true;
            }
            catch (Exception)
            {
                return true;
            }

        }
        //Update Task Details
        public string UpdateTask(Tasks tasks)
        {
            try
            {
                ChecktoAddorUpdate(tasks);
                var task = _tasks.GetById(tasks.Id);
                if (task != null)
                {
                    _tasks.Update(tasks);
                    return "Task Updated!!";
                }
                else
                {
                    return "Task Not Present please add first!!";
                }
            }
            catch (Exception ex)
            {
                return "Exception Occurred";
            }
        }


    }
}